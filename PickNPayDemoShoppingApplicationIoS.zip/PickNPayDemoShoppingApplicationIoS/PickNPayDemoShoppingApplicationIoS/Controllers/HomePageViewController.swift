//
//  HomePageViewController.swift
//  PickNPayDemoShoppingApplicationIoS
//
//  Created by Reverside Software Solutions on 2/22/18.
//  Copyright © 2018 Reverside Software Solutions. All rights reserved.
//

import UIKit
import CoreLocation

//class YourCell : UITableViewCell
//{
//    @IBOutlet weak var imageView_01: UIImageView!
//}


class HomePageViewController: UITableViewController{

    var forecastData = [ProductItem]()
    
    
    var NameOfSelecetedProduct = ""
    
    //@IBOutlet weak var productImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ProductItem.forecast(completion: { (results:[ProductItem]?) in
            
            if let weatherData = results {
                self.forecastData = weatherData
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
            }
            
        })
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    
//    @IBAction func logoutBttnPress(_ sender: Any) {
//        
//        self.performSegue(withIdentifier: "logout", sender: self)
//        
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        print(forecastData.count);
        return forecastData.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }
    
//    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
////        let date = Calendar.current.date(byAdding: .day, value: section, to: Date())
////        let dateFormatter = DateFormatter()
////        dateFormatter.dateFormat = "MMMM dd, yyyy"
//            let weatherObject = forecastData[indexPath.section]
//
//       return weatherObject.ProductName
//    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.estimatedRowHeight = 321
        tableView.rowHeight = 321
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell", for: indexPath) as! CustomTableViewCell
        
        let weatherObject = forecastData[indexPath.section]
        //print(weatherObject)
        //cell.textLabel?.text = weatherObject.ProductName
        //cell.detailTextLabel?.text = "R \((weatherObject.Price))"
        
        cell.productName.text = weatherObject.ProductName
        cell.productPeric.text = "R \((weatherObject.Price))"
        //let url = URL(string:weatherObject.IMG_URL)
        let imageUrlString: String = weatherObject.IMG_URL

        let test = String(imageUrlString.filter { !" \n\t\r".contains($0) })
        
        var imageUrl = URL(string: test)!
        
        var imageData = try! Data(contentsOf: imageUrl)
        
        var image = UIImage(data: imageData)
        
        //cell.imageView?.image = UIImage(data: imageData)
        
       
        cell.imageB?.image = UIImage(data: imageData)
        //cell.imageView_01?.image = UIImage(data: imageData)
        NameOfSelecetedProduct = weatherObject.ProductName
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        let productSelected = forecastData[indexPath.section]
        print("Logged in user is : ")
        let defaults = UserDefaults.standard
        var email = defaults.string(forKey: "Email")
       
        var b = ""
        b = (email?.replacingOccurrences(of: "Optional(", with:""))!
        print(b)
    
        
        //print(productSelected.ProductName)
        
//        let alert = UIAlertController(title: "Add to Cart", message: "Are you sure you want to add \(productSelected.ProductName) to your cart", preferredStyle: .alert)
//
//        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
//
//        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
//
//        self.present(alert, animated: true)
        
        let alertController = UIAlertController(title: "Add to Cart", message: "Are you sure you want to add \(productSelected.ProductName) to your cart", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.default) {
            UIAlertAction in
            
            let url = NSURL(string: "http://picknpaysystemmyversion.000webhostapp.com/AddToCartIOS.php") // locahost MAMP - change to point to your database server
            
            var request = URLRequest(url: url! as URL)
            request.httpMethod = "POST"
            
            var dataString = "secretWord=44fdcv8jf3" // starting POST string with a secretWord
            
            // the POST string has entries separated by &
            
            print()
            dataString = dataString + "&txtName=\(productSelected.ProductName)" // add items as name and value
            dataString = dataString + "&txtDesc=\(productSelected.Description)"
            dataString = dataString + "&txtQty=\(0)"
            dataString = dataString + "&txtPrice=\(productSelected.Price)"
            dataString = dataString + "&txtImageUrl=\(productSelected.IMG_URL)"
            dataString = dataString + "&txtCustomer=\(b)"
            
            
            // convert the post string to utf8 format
            
            
            let dataD = dataString.data(using: .utf8) // convert to utf8 string
            
            do
            {
                
                // the upload task, uploadJob, is defined here
                
                let uploadJob = URLSession.shared.uploadTask(with: request, from: dataD)
                {
                    data, response, error in
                    
                    if error != nil {
                        
                        // display an alert if there is an error inside the DispatchQueue.main.async
                        
                        DispatchQueue.main.async
                            {
                                let alert = UIAlertController(title: "Upload Didn't Work11111?", message: "Looks like the connection to the server didn't work.  Do you have Internet access?", preferredStyle: .alert)
                                //alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                    }
                    else
                    {
                        if let unwrappedData = data {
                            
                            let returnedData = NSString(data: unwrappedData, encoding: String.Encoding.utf8.rawValue) // Response from web server hosting the database
                            
                            if returnedData == "1" // insert into database worked
                            {
                                
                                // display an alert if no error and database insert worked (return = 1) inside the DispatchQueue.main.async
                                
                                DispatchQueue.main.async
                                    {
                                        //let alert = UIAlertController(title: "Registeration succesful", message: name + ", you've sucessfully registered", preferredStyle: .alert)
                                        //alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                                        //self.present(alert, animated: true, completion: nil)
                                }
                            }
                            else
                            {
                                // display an alert if an error and database insert didn't worked (return != 1) inside the DispatchQueue.main.async
                                
                                DispatchQueue.main.async
                                    {
                                        
//
//                                        let alert = UIAlertController(title: "Upload Didn't Work", message: "Looks like the insert into the database did not worked.", preferredStyle: .alert)
//                                        //alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
//                                        self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    }
                }
                uploadJob.resume()
                
            }
            
            
        }
        let cancelAction = UIAlertAction(title: "No", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            NSLog("Cancel Pressed")
        }
        
        // Add the actions
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
        
        print("You selected cell number: \(indexPath.section)!")
        
        
        //self.performSegue(withIdentifier: "Cell", sender: self)
    }
    
    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
